const CACHE_NAME = 'chess-master-v1';

const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png',
  'https://unpkg.com/@chrisoakman/chessboardjs@1.0.0/dist/chessboard-1.0.0.min.css',
  'https://code.jquery.com/jquery-3.6.0.min.js',
  'https://unpkg.com/@chrisoakman/chessboardjs@1.0.0/dist/chessboard-1.0.0.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/chess.js/0.10.3/chess.min.js',
  'https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js',
  'https://chessboardjs.com/img/chesspieces/wikipedia/wP.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/wN.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/wB.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/wR.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/wQ.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/wK.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/bP.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/bN.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/bB.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/bR.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/bQ.png',
  'https://chessboardjs.com/img/chesspieces/wikipedia/bK.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return Promise.all(
        ASSETS.map((url) =>
          fetch(url, { mode: 'no-cors' })
            .then((resp) => cache.put(url, resp))
            .catch(() => {})
        )
      );
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((resp) => {
          const copy = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          return resp;
        })
        .catch(() => cached);
    })
  );
});
